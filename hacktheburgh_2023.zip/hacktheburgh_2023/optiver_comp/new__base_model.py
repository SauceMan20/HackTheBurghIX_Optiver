import logging
from optibook.synchronous_client import Exchange
import time

VERBOSE = False
DO_SLEEP = False
SLEEP_FOR = 0.05

def delete_orders(e, instrument):
    outstanding = e.get_outstanding_orders(instrument)
    for a in outstanding.values(): result = a.delete_order(instrument, order_id = a.order_id)

def extract_pricebook(e, instrument):
    pb = e.get_last_price_book(instrument)
    asks, bids = pb.asks, pb.bids
    
    if len(pb.asks) == 0 or len(pb.bids) == 0: return
    
    ask, bid = pb.asks[0], pb.bids[0]
    
    ask_p, ask_v = ask.price, ask.volume
    bid_p, bid_v = bid.price, bid.volume
    return (ask_p, ask_v, bid_p, bid_v)
    
    
def attempt_trade(e, etf, s1, s2):
    s1ex = extract_pricebook(e, s1) #extraction
    s2ex = extract_pricebook(e, s2)
    eex = extract_pricebook(e, etf)
    
    if s1ex and s2ex and eex:
        s1cap, s1cav, s1cbp, s1cbv = s1ex #(s)tock(1) (c)urrent (a)sk (p)rice etc... (s)tock / (v)olume / (b)id
        s2cap, s2cav, s2cbp, s2cbv = s2ex
        ecap, ecav, ecbp, ecbv = eex
    else: return

    if ecbv == 1: return

    epbp = 0.5 * s1cbp + 0.5 * s2cbp #(e)tf (p)lanned (b)id (p)rice
    epap = 0.5 * s1cap + 0.5 * s2cap
    spread = epap - epbp
    
    pos = e.get_positions()
    
    if pos: epos, s1pos, s2pos = pos[etf], pos[s1], pos[s2]
    else: epos, s1pos, s2pos = 0, 0, 0
        
    f_vol = min(2 * min(s1cav , s2cav), ecbv)
    vol = min(500 - abs(epos), f_vol)
        
    # 1st case: The ETF has a higher bid price than the individual stock ask price
    if ecbp > epap:
        if vol == 0 and epos == -500:  return
        elif vol == 0 and epos == 500: vol = min(f_vol, 500)
        vol //= 2
        
        if VERBOSE: print(f'buying stocks at {s1cap} and {s2cap} V {vol} * 2 and selling etf at {ecbp} V {2*vol}')
        e.insert_order(s1, price = s1cap, volume = vol, side = 'bid', order_type = 'ioc')
        e.insert_order(s2, price = s2cap, volume = vol, side = 'bid', order_type = 'ioc')
        e.insert_order(etf, price = ecbp, volume = 2 * vol, side = 'ask', order_type = 'ioc')

        
    #logging.info(f"etf ask: {current_etf_ask_price} etf as stock bid: {etf_as_stock_bid_price} etf bid: {current_etf_bid_price} etf as stock ask: {etf_as_stock_ask_price}")
    # 2nd case: The ETF has a lower ask price then the individual stock bid price
    # IF the buy price of the etf is less than the sell price of the constructed etf then we sell individual stocks and buy the etf
    if ecap < epbp:
        if vol == 0 and epos == 500:  return
        elif vol == 0 and epos == -500: vol = min(f_vol, 500)
        vol //= 2
        
        if VERBOSE: print(f'buying etf at {ecap} v {2*vol} and selling stocks at {s1cbp} and {s2cbp} v {vol}')
        e.insert_order(etf, price = ecap, volume = 2 * vol, side = 'bid', order_type = 'ioc')
        e.insert_order(s1, price = s1cbp, volume = vol, side = 'ask', order_type = 'ioc')
        e.insert_order(s2, price = s2cbp, volume = vol, side = 'ask', order_type = 'ioc')
            


def main():
    instruments = ["C2_GREEN_ENERGY_ETF", "C2_SOLAR_CO", "CW_WIND_LTD", "C1_FOSSIL_FUEL_ETF", "C1_GAS_INC", "C1_OIL_CORP"]
    try:
        e = Exchange()
        e.connect()
        for instrument in instruments: delete_orders(e, instrument)

        while True:
            attempt_trade(e, "C2_GREEN_ENERGY_ETF", "C2_SOLAR_CO", "C2_WIND_LTD")
            attempt_trade(e, "C!_FOSSIL_FUEL_ETF", "C1_GAS_INC", "C1_OIL_CORP")
            if DO_SLEEP: time.sleep(SLEEP_FOR)

    except:
        print("error in main loop.")
        e.disconnect()
        time.sleep(1)
        

if __name__ == '__main__':
    main()